const CACHE_TTL_MS = 1000 * 60 * 5;
const XUEQIU_BASE = "https://stock.xueqiu.com/v5";

const DEFAULT_CONFIG = {
  xq_a_token: "",
  xq_r_token: "",
  device_id: "",
  openai_api_key: "",
  api_base_url: "https://api.deepseek.com/v1",
  prefer_model: "deepseek-chat",
  cacheTtlMs: CACHE_TTL_MS,
  autoFetchTokens: true,
};

const PERIOD_ORDER = ["q1", "h1", "q3", "q4", "annual"];
const DISPLAY_PERIOD_ORDER = ["q1", "h1", "q3", "annual"];

function cacheKeyForSymbol(symbol) {
  return `stockAnalysis_${symbol}`;
}

function safeGet(obj, path, fallback = null) {
  try {
    return path.split(".").reduce((acc, key) => acc?.[key], obj) ?? fallback;
  } catch {
    return fallback;
  }
}

function toNumber(value) {
  if (value === null || value === undefined || value === "") return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function toNumberFromMaybeArray(value) {
  if (Array.isArray(value)) {
    return toNumber(value[0]);
  }
  return toNumber(value);
}

function normalizePercent(value) {
  const n = toNumber(value);
  return n === null ? null : Number(n.toFixed(2));
}

function createNullPeriodSeries() {
  return {
    q1: null,
    h1: null,
    q3: null,
    q4: null,
    annual: null,
  };
}

function getNumberByKeysAtIndex(record, keys, index) {
  if (!record || typeof record !== "object") return null;
  for (const key of keys) {
    if (!Object.prototype.hasOwnProperty.call(record, key)) continue;
    const value = record[key];
    if (Array.isArray(value)) {
      const n = toNumber(value[index]);
      if (n !== null) {
        return n;
      }
      continue;
    }
    if (index === 0) {
      const n = toNumber(value);
      if (n !== null) {
        return n;
      }
    }
  }
  return null;
}

function setPeriodValue(series, period, value) {
  if (!period || value === null) return;
  if (series[period] === null) {
    series[period] = value;
  }
}

function detectPeriodKey(...rawValues) {
  const hints = [];
  for (const raw of rawValues) {
    if (raw === null || raw === undefined) continue;

    const s = String(raw).trim();
    if (!s) continue;
    hints.push(s.toUpperCase());

    if (/^\d{13}$/.test(s) || /^\d{10}$/.test(s)) {
      const ts = /^\d{10}$/.test(s) ? Number(s) * 1000 : Number(s);
      const d = new Date(ts);
      if (!Number.isNaN(d.getTime())) {
        const mm = String(d.getMonth() + 1).padStart(2, "0");
        const dd = String(d.getDate()).padStart(2, "0");
        hints.push(`${mm}-${dd}`);
        hints.push(`${mm}${dd}`);
      }
    } else if (/^\d{8}$/.test(s)) {
      const mm = s.slice(4, 6);
      const dd = s.slice(6, 8);
      hints.push(`${mm}-${dd}`);
      hints.push(`${mm}${dd}`);
    }
  }

  const text = hints.join(" ");

  if (!text) return null;

  if (/(年报|年度|ANNUAL|FY)/.test(text)) return "annual";
  if (/(四季报|四季度|四季|Q4)/.test(text)) return "q4";
  if (/(三季报|三季度|三季|Q3)/.test(text)) return "q3";
  if (/(中报|半年报|半年度|H1|Q2)/.test(text)) return "h1";
  if (/(一季报|一季度|一季|Q1)/.test(text)) return "q1";

  if (/(03-31|0331)/.test(text)) return "q1";
  if (/(06-30|0630)/.test(text)) return "h1";
  if (/(09-30|0930)/.test(text)) return "q3";
  if (/(12-31|1231)/.test(text)) return "annual";

  return null;
}

function extractMetricSeriesFromList(list, metricKeys) {
  const series = createNullPeriodSeries();
  const records = Array.isArray(list) ? list : [];

  for (const record of records) {
    if (!record || typeof record !== "object") continue;

    const directPeriod = detectPeriodKey(
      record.report_name,
      record.report_name_cn,
      record.report_type,
      record.report_date,
      record.report_date_str
    );
    // 雪球财务字段通常是 [当期值, 同比]，这里直接取当期值映射到当前 report_period
    const directValue = getNumberByKeys(record, metricKeys);
    setPeriodValue(series, directPeriod, directValue);

    const metaArrays = [
      record.report_name,
      record.report_name_cn,
      record.report_type,
      record.report_date,
      record.report_date_str,
    ].filter(Array.isArray);
    const metricArrays = metricKeys
      .map((k) => record[k])
      .filter(Array.isArray);
    const maxLength = Math.max(
      0,
      ...metaArrays.map((arr) => arr.length),
      ...metricArrays.map((arr) => arr.length)
    );

    for (let i = 0; i < maxLength; i += 1) {
      const period = detectPeriodKey(
        Array.isArray(record.report_name) ? record.report_name[i] : null,
        Array.isArray(record.report_name_cn) ? record.report_name_cn[i] : null,
        Array.isArray(record.report_type) ? record.report_type[i] : null,
        Array.isArray(record.report_date) ? record.report_date[i] : null,
        Array.isArray(record.report_date_str) ? record.report_date_str[i] : null
      );
      const value = getNumberByKeysAtIndex(record, metricKeys, i);
      setPeriodValue(series, period, value);
    }
  }

  return series;
}

function mergePeriodSeries(primarySeries, fallbackSeries) {
  const merged = createNullPeriodSeries();
  for (const key of PERIOD_ORDER) {
    merged[key] =
      primarySeries?.[key] !== null && primarySeries?.[key] !== undefined
        ? primarySeries[key]
        : fallbackSeries?.[key] ?? null;
  }
  return merged;
}

function subtractPeriodSeries(leftSeries, rightSeries) {
  const result = createNullPeriodSeries();
  for (const key of PERIOD_ORDER) {
    const left = leftSeries?.[key];
    const right = rightSeries?.[key];
    if (left !== null && left !== undefined && right !== null && right !== undefined) {
      result[key] = left - right;
    }
  }
  return result;
}

function calculateRatioSeries(numeratorSeries, denominatorSeries, multiplier = 1) {
  const result = createNullPeriodSeries();
  for (const key of PERIOD_ORDER) {
    const numerator = numeratorSeries?.[key];
    const denominator = denominatorSeries?.[key];
    if (
      numerator !== null &&
      numerator !== undefined &&
      denominator !== null &&
      denominator !== undefined &&
      denominator !== 0
    ) {
      result[key] = Number(((numerator / denominator) * multiplier).toFixed(2));
    }
  }
  return result;
}

function pickPreferredPeriodEntry(series) {
  const priority = ["annual", "q4", "q3", "h1", "q1"];
  for (const key of priority) {
    const value = series?.[key];
    if (value !== null && value !== undefined) {
      return { key, value };
    }
  }
  return null;
}

function pickPreferredPeriodValue(series) {
  const entry = pickPreferredPeriodEntry(series);
  return entry ? entry.value : null;
}

function formatPeriodSeriesForPrompt(series, suffix = "") {
  return DISPLAY_PERIOD_ORDER.map((key) => {
    const value = series?.[key];
    return value === null || value === undefined ? "NULL" : `${value}${suffix}`;
  }).join(" | ");
}

function getNumberByKeys(record, keys) {
  if (!record || typeof record !== "object") return null;
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(record, key)) {
      const n = toNumberFromMaybeArray(record[key]);
      if (n !== null) {
        return n;
      }
    }
  }
  return null;
}

async function getXueqiuTokensFromCookies() {
  try {
    const cookies = await chrome.cookies.getAll({ domain: "xueqiu.com" });
    const tokenNames = new Set([
      "xq_a_token",
      "xq_r_token",
      "xq_token",
      "device_id",
      "u",
      "s",
    ]);

    const result = {};
    for (const cookie of cookies) {
      if (tokenNames.has(cookie.name)) {
        result[cookie.name] = cookie.value;
      }
    }

    return result;
  } catch (error) {
    console.error("获取雪球 cookies 失败:", error);
    return {};
  }
}

function mergeCookieTokens(config, cookieTokens) {
  return {
    ...config,
    xq_a_token: config.xq_a_token || cookieTokens.xq_a_token || "",
    xq_r_token: config.xq_r_token || cookieTokens.xq_r_token || "",
    device_id: config.device_id || cookieTokens.device_id || "",
  };
}

async function getConfig() {
  const config = await chrome.storage.sync.get(DEFAULT_CONFIG);
  if (!config.autoFetchTokens) {
    return config;
  }

  const cookieTokens = await getXueqiuTokensFromCookies();
  return mergeCookieTokens(config, cookieTokens);
}

class XueqiuApiClient {
  constructor(config) {
    this.config = config;
  }

  async request(endpoint, params = {}) {
    const url = new URL(endpoint, XUEQIU_BASE);
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        url.searchParams.set(key, String(value));
      }
    });

    const headers = {
      Accept: "application/json, text/plain, */*",
      Referer: "https://xueqiu.com/",
    };

    const response = await fetch(url.toString(), {
      method: "GET",
      headers,
      credentials: "include",
    });

    if (!response.ok) {
      const body = await response.text();
      throw new Error(`雪球接口失败 ${response.status}: ${body.slice(0, 200)}`);
    }

    return response.json();
  }

  async getAnalysisBundle(symbol) {
    const tasks = {
      realtime: this.request("/stock/realtime/quotec.json", { symbol }),
      detail: this.request("/stock/quote.json", { symbol, extend: "detail" }),
      indicator: this.request("/stock/finance/cn/indicator.json", {
        symbol,
        type: "all",
        is_detail: true,
        count: 6,
      }),
      income: this.request("/stock/finance/cn/income.json", {
        symbol,
        type: "all",
        is_detail: true,
        count: 6,
      }),
      balance: this.request("/stock/finance/cn/balance.json", {
        symbol,
        type: "all",
        is_detail: true,
        count: 6,
      }),
      cashFlow: this.request("/stock/finance/cn/cash_flow.json", {
        symbol,
        type: "all",
        is_detail: true,
        count: 6,
      }),
      shareholders: this.request("/stock/f10/cn/skholder.json", { symbol }),
      bonus: this.request("/stock/f10/cn/bonus.json", { symbol, page: 1, size: 5 }),
    };

    const entries = Object.entries(tasks);
    const settled = await Promise.allSettled(entries.map(([, promise]) => promise));

    const data = {};
    const errors = {};

    settled.forEach((item, index) => {
      const key = entries[index][0];
      if (item.status === "fulfilled") {
        data[key] = item.value;
      } else {
        errors[key] = item.reason?.message || "unknown_error";
      }
    });

    return { data, errors };
  }
}

function normalizeSnapshot(symbol, payload) {
  const realtimeQuote = safeGet(payload, "realtime.data.0", {});
  const detailQuote = safeGet(payload, "detail.data.quote", {});
  const indicatorList = safeGet(payload, "indicator.data.list", []);
  const incomeList = safeGet(payload, "income.data.list", []);
  const balanceList = safeGet(payload, "balance.data.list", []);
  const cashFlowList = safeGet(payload, "cashFlow.data.list", []);
  const shareholderList = safeGet(payload, "shareholders.data.items", []);
  const bonusList = safeGet(payload, "bonus.data.items", []);

  const latestIndicator = indicatorList[0] || {};
  const latestIncome = incomeList[0] || {};
  const latestBalance = balanceList[0] || {};
  const latestCashFlow = cashFlowList[0] || {};
  const topHolder = shareholderList[0] || {};
  const latestBonus = bonusList[0] || {};

  const name =
    safeGet(realtimeQuote, "name") ||
    safeGet(detailQuote, "name") ||
    safeGet(latestIndicator, "company_name") ||
    symbol;

  const netProfitGrowth = toNumber(safeGet(latestIndicator, "net_profit_atsopc_yoy.0"));
  const peTtm = toNumber(safeGet(detailQuote, "pe_ttm"));
  const directRoe = normalizePercent(safeGet(detailQuote, "roe"));
  const roeDirectSeries = extractMetricSeriesFromList(indicatorList, [
    "roe",
    "avg_roe",
    "weighted_roe",
    "roe_weighted",
  ]);
  const roeProfitSeries = extractMetricSeriesFromList(incomeList, [
    "net_profit_atsopc",
    "parent_net_profit",
    "net_profit",
    "np_atsopc",
    "net_profit_parent_company",
    "n_income",
  ]);
  const equitySeriesDirect = extractMetricSeriesFromList(balanceList, [
    "total_holders_equity_atsopc",
    "total_holders_equity_exc_min_int",
    "total_holders_equity",
    "equity_atsopc",
    "owner_equities_atsopc",
    "equities_parent_company_owners",
    "total_owner_equities",
    "tot_equity",
  ]);
  const totalAssetsSeries = extractMetricSeriesFromList(balanceList, ["total_assets"]);
  const totalLiabSeries = extractMetricSeriesFromList(balanceList, ["total_liab"]);
  const equitySeriesFallback = subtractPeriodSeries(totalAssetsSeries, totalLiabSeries);
  const roeEquitySeries = mergePeriodSeries(equitySeriesDirect, equitySeriesFallback);
  const roeCalculatedSeries = calculateRatioSeries(roeProfitSeries, roeEquitySeries, 100);
  // 需求要求 ROE 统一按公式计算：净利润 / 期末净资产 * 100，直接指标仅作兜底
  const roeSeries = mergePeriodSeries(roeCalculatedSeries, roeDirectSeries);
  const roePreferred = pickPreferredPeriodEntry(roeSeries);
  const finalRoe = (roePreferred ? roePreferred.value : null) ?? directRoe;
  const roeSource =
    roePreferred
      ? roeCalculatedSeries[roePreferred.key] !== null && roeCalculatedSeries[roePreferred.key] !== undefined
        ? "series.calculated(net_profit_atsopc/equity)"
        : "series.direct(indicator)"
      : directRoe !== null
        ? "quote.roe"
        : null;
  const roeNumeratorNetProfit = roePreferred
    ? roeProfitSeries[roePreferred.key]
    : pickPreferredPeriodValue(roeProfitSeries);
  const roeDenominatorEquity = roePreferred
    ? roeEquitySeries[roePreferred.key]
    : pickPreferredPeriodValue(roeEquitySeries);

  const operatingCashFlowSeries = extractMetricSeriesFromList(cashFlowList, [
    "ncf_from_oa",
    "ncf_operate_a",
    "ncf_from_operate_a",
    "net_cf_operate_a",
  ]);
  const netProfitSeries = extractMetricSeriesFromList(incomeList, [
    "net_profit",
    "net_profit_atsopc",
    "parent_net_profit",
    "np_atsopc",
    "net_profit_parent_company",
    "n_income",
  ]);
  const cashToProfitRatioSeries = calculateRatioSeries(
    operatingCashFlowSeries,
    netProfitSeries,
    1
  );
  const cashToProfitPreferred = pickPreferredPeriodEntry(cashToProfitRatioSeries);
  const operatingCashFlow = cashToProfitPreferred
    ? operatingCashFlowSeries[cashToProfitPreferred.key]
    : pickPreferredPeriodValue(operatingCashFlowSeries);
  const netProfit = cashToProfitPreferred
    ? netProfitSeries[cashToProfitPreferred.key]
    : pickPreferredPeriodValue(netProfitSeries);
  const cashToProfitRatio = cashToProfitPreferred ? cashToProfitPreferred.value : null;
  const cashToProfitRatioSource =
    cashToProfitRatio !== null ? "series.calculated(ncf_from_oa/net_profit)" : null;

  return {
    symbol,
    name,
    quote: {
      current: toNumber(safeGet(realtimeQuote, "current")),
      percent: normalizePercent(safeGet(realtimeQuote, "percent")),
      volume: toNumber(safeGet(realtimeQuote, "volume")),
      amount: toNumber(safeGet(realtimeQuote, "amount")),
      marketCap: toNumber(safeGet(detailQuote, "market_capital")),
    },
    valuation: {
      peTtm,
      pb: toNumber(safeGet(detailQuote, "pb")),
      psTtm: toNumber(safeGet(detailQuote, "ps_ttm")),
      dividendYield: normalizePercent(safeGet(detailQuote, "dividend_yield")),
      peg:
        peTtm !== null && netProfitGrowth !== null && netProfitGrowth > 0
          ? Number((peTtm / netProfitGrowth).toFixed(2))
          : null,
    },
    profitability: {
      roe: finalRoe,
      roeSeries,
      roeSource,
      roeNumeratorNetProfit,
      roeDenominatorEquity,
      grossMargin: normalizePercent(safeGet(latestIndicator, "gross_selling_rate.0")),
      netMargin: normalizePercent(safeGet(latestIndicator, "net_profit_margin.0")),
      eps: toNumber(safeGet(latestIndicator, "basic_eps.0")),
      netProfitGrowth: normalizePercent(netProfitGrowth),
      revenueGrowth: normalizePercent(safeGet(latestIndicator, "total_revenue_yoy.0")),
    },
    balanceSheet: {
      debtAssetRatio: normalizePercent(safeGet(latestBalance, "asset_liab_ratio.0")),
      currentRatio: toNumber(safeGet(latestBalance, "current_ratio.0")),
      quickRatio: toNumber(safeGet(latestBalance, "quick_ratio.0")),
    },
    cashFlow: {
      operatingCashFlow,
      netProfit,
      cashToProfitRatio,
      cashToProfitRatioSeries,
      cashToProfitRatioSource,
      investingCashFlow: toNumber(safeGet(latestCashFlow, "ncf_from_ia.0")),
      financingCashFlow: toNumber(safeGet(latestCashFlow, "ncf_from_fa.0")),
    },
    shareholder: {
      topHolderName: safeGet(topHolder, "name", null),
      topHolderRatio: normalizePercent(safeGet(topHolder, "held_ratio")),
      latestDividendPerShare: toNumber(safeGet(latestBonus, "dividend_per_share")),
    },
    rawPreview: {
      indicatorPeriods: indicatorList.length,
      incomePeriods: incomeList.length,
      balancePeriods: balanceList.length,
      cashFlowPeriods: cashFlowList.length,
      shareholderRecords: shareholderList.length,
      bonusRecords: bonusList.length,
    },
  };
}

function compactSnapshotText(snapshot) {
  const lines = [
    `股票: ${snapshot.name} (${snapshot.symbol})`,
    `现价: ${snapshot.quote.current ?? "N/A"}`,
    `涨跌幅: ${snapshot.quote.percent ?? "N/A"}%`,
    `PE(TTM): ${snapshot.valuation.peTtm ?? "N/A"}`,
    `PB: ${snapshot.valuation.pb ?? "N/A"}`,
    `PEG: ${snapshot.valuation.peg ?? "N/A"}`,
    `ROE: ${snapshot.profitability.roe ?? "N/A"}%`,
    `ROE序列(1季度/中报/3季度/年报): ${formatPeriodSeriesForPrompt(snapshot.profitability.roeSeries, "%")}`,
    `ROE来源: ${snapshot.profitability.roeSource ?? "N/A"}`,
    `净利增速: ${snapshot.profitability.netProfitGrowth ?? "N/A"}%`,
    `营收增速: ${snapshot.profitability.revenueGrowth ?? "N/A"}%`,
    `资产负债率: ${snapshot.balanceSheet.debtAssetRatio ?? "N/A"}%`,
    `经营现金流: ${snapshot.cashFlow.operatingCashFlow ?? "N/A"}`,
    `净利润: ${snapshot.cashFlow.netProfit ?? "N/A"}`,
    `净现比(经营现金流净额/净利润): ${snapshot.cashFlow.cashToProfitRatio ?? "N/A"}`,
    `净现比序列(1季度/中报/3季度/年报): ${formatPeriodSeriesForPrompt(snapshot.cashFlow.cashToProfitRatioSeries)}`,
    `股息率: ${snapshot.valuation.dividendYield ?? "N/A"}%`,
    `第一大股东: ${snapshot.shareholder.topHolderName || "N/A"} (${snapshot.shareholder.topHolderRatio ?? "N/A"}%)`,
  ];
  return lines.join("\n");
}

function buildBuffettPrompt(snapshot) {
  return `你是一名长期主义价值投资分析师，请严格按“巴菲特价值投资方法论”分析。\n\n` +
    `请围绕以下原则给出研判：\n` +
    `1) 能力圈与商业模式可理解性\n` +
    `2) 护城河（品牌/渠道/成本/网络效应）\n` +
    `3) 管理层质量（资本配置、分红/回购、一致性）\n` +
    `4) 财务质量（ROE、利润率、现金流、负债安全）\n` +
    `5) 估值与安全边际（PE/PB/PEG 与增长匹配）\n` +
    `6) 风险与反证（你最担心的 3 个点）\n\n` +
    `数据快照：\n${compactSnapshotText(snapshot)}\n\n` +
    `请输出中文，并按下面固定结构：\n` +
    `【一句话结论】\n` +
    `【巴菲特六维评分】每项 1-10 分，并说明理由\n` +
    `【关键证据】至少 5 条，必须引用上面数据\n` +
    `【安全边际判断】给出“低估/合理/高估”之一\n` +
    `【操作建议】给出“买入/观察/回避”之一，并给出适用前提\n` +
    `【风险清单】列出最关键的 3 条。`;
}

async function callOpenAICompatible(prompt, config) {
  if (!config.openai_api_key) {
    throw new Error("未配置大模型 API Key，请先在插件设置中填写。");
  }

  const baseUrl = (config.api_base_url || DEFAULT_CONFIG.api_base_url).replace(/\/$/, "");
  const model = config.prefer_model || DEFAULT_CONFIG.prefer_model;

  const response = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${config.openai_api_key}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        {
          role: "system",
          content:
            "你是严谨的价值投资研究员。你必须基于输入数据做推理，不得编造未提供的事实。",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.4,
      max_tokens: 1800,
    }),
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`大模型调用失败 ${response.status}: ${body.slice(0, 300)}`);
  }

  const json = await response.json();
  const content = safeGet(json, "choices.0.message.content", "");
  if (!content) {
    throw new Error("大模型返回为空");
  }

  return content.trim();
}

async function readCache(symbol) {
  const key = cacheKeyForSymbol(symbol);
  const items = await chrome.storage.local.get([key]);
  const entry = items[key];
  if (!entry) return null;
  if (Date.now() - entry.ts > (entry.ttl ?? CACHE_TTL_MS)) return null;
  return entry.value;
}

async function writeCache(symbol, value, ttlMs = CACHE_TTL_MS) {
  const key = cacheKeyForSymbol(symbol);
  await chrome.storage.local.set({
    [key]: {
      ts: Date.now(),
      ttl: ttlMs,
      value,
    },
  });
}

function hasUsableBundleData(data) {
  return !!(data?.realtime || data?.detail || data?.indicator);
}

async function analyzeSymbol(symbol, forceRefresh = false, prefetchedBundle = null) {
  const config = await getConfig();

  if (!forceRefresh) {
    const cached = await readCache(symbol);
    if (cached) {
      return cached;
    }
  }

  let bundle = prefetchedBundle;
  if (!bundle || !hasUsableBundleData(bundle.data)) {
    const client = new XueqiuApiClient(config);
    bundle = await client.getAnalysisBundle(symbol);
  }

  if (!bundle.data.realtime && !bundle.data.detail && !bundle.data.indicator) {
    const detail = bundle.errors ? ` 失败详情: ${JSON.stringify(bundle.errors)}` : "";
    throw new Error(`无法获取雪球数据，请确认已登录雪球并刷新页面后重试。${detail}`);
  }

  const snapshot = normalizeSnapshot(symbol, bundle.data);
  const prompt = buildBuffettPrompt(snapshot);
  const analysis = await callOpenAICompatible(prompt, config);

  const result = {
    fetchedAt: Date.now(),
    symbol,
    name: snapshot.name,
    snapshot,
    analysis,
    sourceErrors: bundle.errors,
    rawData: bundle.data,
  };

  await writeCache(symbol, result, config.cacheTtlMs || CACHE_TTL_MS);
  return result;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "refreshTokens") {
    (async () => {
      try {
        const tokens = await getXueqiuTokensFromCookies();
        sendResponse({ ok: true, tokens });
      } catch (error) {
        sendResponse({ ok: false, error: error.message || String(error) });
      }
    })();
    return true;
  }

  if (message?.type === "getStockAnalysis") {
    (async () => {
      try {
        const symbol = String(message.symbol || "").toUpperCase().trim();
        if (!symbol) {
          throw new Error("未识别到股票代码");
        }

        const prefetchedBundle =
          message.prefetchedBundle && typeof message.prefetchedBundle === "object"
            ? message.prefetchedBundle
            : null;

        const result = await analyzeSymbol(symbol, !!message.forceRefresh, prefetchedBundle);
        sendResponse({ ok: true, data: result });
      } catch (error) {
        console.error("分析失败:", error);
        sendResponse({ ok: false, error: error.message || String(error) });
      }
    })();

    return true;
  }
});
