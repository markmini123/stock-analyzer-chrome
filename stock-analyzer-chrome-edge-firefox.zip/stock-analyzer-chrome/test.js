// 测试脚本 - 验证插件功能
// 在浏览器控制台中运行此脚本测试

console.log('🧪 开始测试雪球股票分析插件...');

// 测试1: 检查background script是否加载
chrome.runtime.sendMessage({ type: 'test' }, (response) => {
  if (chrome.runtime.lastError) {
    console.log('❌ Background script 未响应');
  } else {
    console.log('✅ Background script 正常运行');
  }
});

// 测试2: 检查配置是否正确加载
chrome.storage.sync.get(['openai_api_key', 'api_base_url'], (items) => {
  console.log('🔧 当前配置:');
  console.log('  - API Key:', items.openai_api_key ? '已配置' : '未配置');
  console.log('  - API URL:', items.api_base_url || '未配置');
});

// 测试3: 模拟股票分析请求
function testStockAnalysis() {
  console.log('📊 测试股票分析功能...');

  chrome.runtime.sendMessage({
    type: 'getStockAnalysis',
    symbol: 'SH600519'
  }, (response) => {
    if (response?.ok) {
      console.log('✅ 分析成功!');
      console.log('📈 股票信息:', response.data.name, response.data.symbol);
      console.log('🤖 AI分析:', response.data.analysis.substring(0, 200) + '...');
    } else {
      console.error('❌ 分析失败:', response?.error);
    }
  });
}

// 延迟3秒后运行测试
setTimeout(testStockAnalysis, 3000);

console.log('⏳ 测试脚本已启动，请等待结果...');