const STATE = {
  panel: null,
  statusEl: null,
  contentEl: null,
  progressEl: null,
  progressTextEl: null,
  isAnalyzing: false,
  lastTriggerAt: 0,
  triggerIntervalMs: 1500,
  lastResult: null,
  clickTriggerEnabled: true,
};

const DISPLAY_PERIOD_ORDER = ["q1", "h1", "q3", "annual"];
const EXT_INVALIDATED_MSG = "扩展已更新或重载，请刷新当前雪球页面后重试。";

function isExtensionContextValid() {
  return !!(chrome?.runtime?.id);
}

function isContextInvalidatedErrorMessage(message) {
  if (!message) return false;
  const text = String(message);
  return (
    text.includes("Extension context invalidated") ||
    text.includes("message port closed") ||
    text.includes("Receiving end does not exist")
  );
}

function extractSymbolFromUrl() {
  const path = window.location.pathname || "";

  const fullMatch = path.match(/\/S\/([A-Z]{2}\d{5,6})/i);
  if (fullMatch) {
    return fullMatch[1].toUpperCase();
  }

  const shortMatch = path.match(/\/S\/(\d{6})/);
  if (shortMatch) {
    const code = shortMatch[1];
    const market = code.startsWith("6") ? "SH" : "SZ";
    return `${market}${code}`;
  }

  return null;
}

function fmt(value, suffix = "") {
  if (value === null || value === undefined || value === "") return "N/A";
  if (typeof value === "number") {
    return `${value.toLocaleString("zh-CN", { maximumFractionDigits: 2 })}${suffix}`;
  }
  return `${value}${suffix}`;
}

function formatPeriodSeries(series, suffix = "") {
  return DISPLAY_PERIOD_ORDER.map((key) => {
    const value = series?.[key];
    return value === null || value === undefined ? "NULL" : `${fmt(value)}${suffix}`;
  }).join(" | ");
}

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

function downloadText(filename, content, mime = "text/plain;charset=utf-8") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function ensurePanel() {
  if (STATE.panel && document.body.contains(STATE.panel)) {
    return;
  }

  const panel = document.createElement("section");
  panel.id = "xq-value-analyzer-panel";
  panel.style.position = "fixed";
  panel.style.top = "84px";
  panel.style.right = "14px";
  panel.style.width = "420px";
  panel.style.maxHeight = "78vh";
  panel.style.overflow = "auto";
  panel.style.background = "#ffffff";
  panel.style.border = "1px solid #d7dbe3";
  panel.style.borderRadius = "12px";
  panel.style.boxShadow = "0 12px 30px rgba(20, 33, 61, 0.22)";
  panel.style.zIndex = "2147483647";
  panel.style.fontFamily = "-apple-system, BlinkMacSystemFont, Segoe UI, sans-serif";
  panel.style.fontSize = "13px";
  panel.style.color = "#1f2937";

  const header = document.createElement("div");
  header.style.padding = "10px 12px";
  header.style.position = "sticky";
  header.style.top = "0";
  header.style.background = "#f8fbff";
  header.style.borderBottom = "1px solid #dfe6f0";
  header.style.display = "flex";
  header.style.alignItems = "flex-start";
  header.style.justifyContent = "space-between";
  header.style.gap = "8px";

  const titleBlock = document.createElement("div");
  titleBlock.style.display = "flex";
  titleBlock.style.flexDirection = "column";
  titleBlock.style.gap = "2px";

  const title = document.createElement("strong");
  title.textContent = "雪球AI投资伴侣";

  const author = document.createElement("div");
  author.textContent = "作者：markmini";
  author.style.fontSize = "11px";
  author.style.color = "#64748b";

  titleBlock.append(title, author);

  const actions = document.createElement("div");
  actions.style.display = "flex";
  actions.style.gap = "6px";

  const reAnalyzeBtn = document.createElement("button");
  reAnalyzeBtn.textContent = "重跑";

  const refreshBtn = document.createElement("button");
  refreshBtn.textContent = "强刷";

  const exportJsonBtn = document.createElement("button");
  exportJsonBtn.textContent = "导出JSON";

  const exportTxtBtn = document.createElement("button");
  exportTxtBtn.textContent = "导出TXT";

  const closeBtn = document.createElement("button");
  closeBtn.textContent = "关闭";

  for (const button of [reAnalyzeBtn, refreshBtn, exportJsonBtn, exportTxtBtn, closeBtn]) {
    button.style.border = "1px solid #c8d3e2";
    button.style.background = "#ffffff";
    button.style.color = "#1f2937";
    button.style.borderRadius = "6px";
    button.style.padding = "3px 8px";
    button.style.cursor = "pointer";
    button.style.fontSize = "12px";
  }

  reAnalyzeBtn.style.background = "#1155cc";
  reAnalyzeBtn.style.color = "#ffffff";
  reAnalyzeBtn.style.border = "1px solid #1155cc";

  actions.append(reAnalyzeBtn, refreshBtn, exportJsonBtn, exportTxtBtn, closeBtn);
  header.append(titleBlock, actions);

  const body = document.createElement("div");
  body.style.padding = "10px 12px 14px";

  const status = document.createElement("div");
  status.style.color = "#475569";
  status.style.marginBottom = "8px";

  const progressWrap = document.createElement("div");
  progressWrap.style.marginBottom = "8px";
  progressWrap.style.display = "none";

  const progressOuter = document.createElement("div");
  progressOuter.style.height = "6px";
  progressOuter.style.background = "#e6edf8";
  progressOuter.style.borderRadius = "8px";
  progressOuter.style.overflow = "hidden";

  const progressInner = document.createElement("div");
  progressInner.style.height = "100%";
  progressInner.style.width = "0%";
  progressInner.style.background = "#1155cc";
  progressInner.style.transition = "width .2s ease";

  const progressText = document.createElement("div");
  progressText.style.fontSize = "12px";
  progressText.style.color = "#64748b";
  progressText.style.marginTop = "4px";

  progressOuter.appendChild(progressInner);
  progressWrap.append(progressOuter, progressText);

  const content = document.createElement("div");
  content.innerHTML = `<p style="margin: 0;">在当前股票页任意位置左键点击即可触发分析。</p>`;

  body.append(status, progressWrap, content);
  panel.append(header, body);
  document.body.appendChild(panel);

  STATE.panel = panel;
  STATE.statusEl = status;
  STATE.contentEl = content;
  STATE.progressEl = progressInner;
  STATE.progressTextEl = progressText;

  reAnalyzeBtn.addEventListener("click", () => startAnalysis({ forceRefresh: false, trigger: "button" }));
  refreshBtn.addEventListener("click", () => startAnalysis({ forceRefresh: true, trigger: "button" }));
  exportJsonBtn.addEventListener("click", () => exportAnalysis("json"));
  exportTxtBtn.addEventListener("click", () => exportAnalysis("txt"));
  closeBtn.addEventListener("click", () => {
    STATE.clickTriggerEnabled = false;
    panel.remove();
    STATE.panel = null;
  });
}

function setStatus(message, color = "#475569") {
  ensurePanel();
  STATE.statusEl.textContent = message;
  STATE.statusEl.style.color = color;
}

function setProgress(percent, message) {
  ensurePanel();
  const wrap = STATE.progressEl.parentElement.parentElement;
  wrap.style.display = "block";
  STATE.progressEl.style.width = `${percent}%`;
  STATE.progressTextEl.textContent = message;
}

function hideProgress() {
  if (!STATE.progressEl) return;
  const wrap = STATE.progressEl.parentElement.parentElement;
  wrap.style.display = "none";
  STATE.progressEl.style.width = "0%";
  STATE.progressTextEl.textContent = "";
}

function buildSnapshotTable(snapshot) {
  const quote = snapshot.quote || {};
  const valuation = snapshot.valuation || {};
  const profitability = snapshot.profitability || {};
  const balanceSheet = snapshot.balanceSheet || {};
  const cashFlow = snapshot.cashFlow || {};

  const rows = [
    ["现价", fmt(quote.current)],
    ["涨跌幅", fmt(quote.percent, "%")],
    ["PE(TTM)", fmt(valuation.peTtm)],
    ["PB", fmt(valuation.pb)],
    ["PEG", fmt(valuation.peg)],
    ["ROE", formatPeriodSeries(profitability.roeSeries, "%")],
    ["净利增速", fmt(profitability.netProfitGrowth, "%")],
    ["资产负债率", fmt(balanceSheet.debtAssetRatio, "%")],
    ["净现比", formatPeriodSeries(cashFlow.cashToProfitRatioSeries)],
    ["股息率", fmt(valuation.dividendYield, "%")],
  ];

  return `
    <table style="width:100%; border-collapse: collapse; margin-bottom: 8px;">
      ${rows
        .map(
          ([key, value]) =>
            `<tr><td style="padding:4px 0; color:#64748b; width:110px;">${escapeHtml(key)}</td><td style="padding:4px 0; font-weight:600;">${escapeHtml(
              value
            )}</td></tr>`
        )
        .join("")}
    </table>
  `;
}

function renderResult(result) {
  ensurePanel();
  const snapshot = result.snapshot || {};
  const sourceErrors = result.sourceErrors || {};

  const errorsText = Object.keys(sourceErrors).length
    ? `<div style="margin:8px 0; padding:8px; border:1px solid #fde68a; border-radius:8px; background:#fff8db; color:#8a4b00;">部分数据接口失败：${escapeHtml(
        JSON.stringify(sourceErrors)
      )}</div>`
    : "";

  STATE.contentEl.innerHTML = `
    <div style="margin-bottom: 8px;">
      <div style="font-size:15px; font-weight:700;">${escapeHtml(result.name)} (${escapeHtml(result.symbol)})</div>
      <div style="font-size:12px; color:#64748b;">更新时间：${new Date(result.fetchedAt).toLocaleString()}</div>
    </div>
    ${buildSnapshotTable(snapshot)}
    ${errorsText}
    <div style="font-size:12px; color:#64748b; margin:8px 0 4px;">巴菲特框架分析</div>
    <pre style="white-space: pre-wrap; word-break: break-word; margin:0; padding:10px; background:#f8fafc; border-radius:8px; border:1px solid #e2e8f0; line-height:1.55;">${escapeHtml(
      result.analysis || ""
    )}</pre>
  `;
}

async function fetchXueqiuBundleFromPage(symbol) {
  const base = "https://stock.xueqiu.com/v5";
  const requests = {
    realtime: [`${base}/stock/realtime/quotec.json`, { symbol }],
    detail: [`${base}/stock/quote.json`, { symbol, extend: "detail" }],
    indicator: [
      `${base}/stock/finance/cn/indicator.json`,
      { symbol, type: "all", is_detail: true, count: 6 },
    ],
    income: [
      `${base}/stock/finance/cn/income.json`,
      { symbol, type: "all", is_detail: true, count: 6 },
    ],
    balance: [
      `${base}/stock/finance/cn/balance.json`,
      { symbol, type: "all", is_detail: true, count: 6 },
    ],
    cashFlow: [
      `${base}/stock/finance/cn/cash_flow.json`,
      { symbol, type: "all", is_detail: true, count: 6 },
    ],
    shareholders: [`${base}/stock/f10/cn/skholder.json`, { symbol }],
    bonus: [`${base}/stock/f10/cn/bonus.json`, { symbol, page: 1, size: 5 }],
  };

  const entries = Object.entries(requests);
  const settled = await Promise.allSettled(
    entries.map(async ([, [url, params]]) => {
      const requestUrl = new URL(url);
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          requestUrl.searchParams.set(key, String(value));
        }
      });

      const resp = await fetch(requestUrl.toString(), {
        credentials: "include",
        headers: {
          Accept: "application/json, text/plain, */*",
        },
      });

      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(`${resp.status}: ${text.slice(0, 200)}`);
      }

      return resp.json();
    })
  );

  const data = {};
  const errors = {};
  settled.forEach((item, index) => {
    const key = entries[index][0];
    if (item.status === "fulfilled") {
      data[key] = item.value;
    } else {
      errors[key] = item.reason?.message || "unknown_error";
    }
  });

  return { data, errors };
}

async function requestAnalysisWithBundle(symbol, forceRefresh, prefetchedBundle) {
  return new Promise((resolve) => {
    if (!isExtensionContextValid()) {
      resolve({ ok: false, error: EXT_INVALIDATED_MSG });
      return;
    }

    try {
      chrome.runtime.sendMessage(
        {
          type: "getStockAnalysis",
          symbol,
          forceRefresh,
          prefetchedBundle,
        },
        (response) => {
          const err = chrome.runtime.lastError;
          if (err) {
            resolve({ ok: false, error: isContextInvalidatedErrorMessage(err.message) ? EXT_INVALIDATED_MSG : err.message });
            return;
          }
          resolve(response);
        }
      );
    } catch (error) {
      resolve({
        ok: false,
        error: isContextInvalidatedErrorMessage(error?.message) ? EXT_INVALIDATED_MSG : (error?.message || String(error)),
      });
    }
  });
}

async function startAnalysis({ forceRefresh, trigger }) {
  const symbol = extractSymbolFromUrl();
  if (!symbol) return;

  ensurePanel();

  if (STATE.isAnalyzing) {
    setStatus("分析进行中，请稍候...", "#8a4b00");
    return;
  }

  STATE.isAnalyzing = true;
  setStatus(`已触发分析（${trigger}）: ${symbol}`, "#1155cc");
  setProgress(15, "识别股票代码...");

  try {
    setProgress(35, "在雪球页面上下文拉取数据...");
    const bundle = await fetchXueqiuBundleFromPage(symbol);
    setProgress(65, "调用后台生成价值分析...");
    const response = await requestAnalysisWithBundle(symbol, forceRefresh, bundle);

    setProgress(85, "生成巴菲特价值分析...");

    if (!response?.ok) {
      throw new Error(response?.error || "未知错误");
    }

    STATE.lastResult = response.data;
    renderResult(response.data);
    setStatus(`分析完成：${response.data.name} (${symbol})`, "#166534");
    setProgress(100, "完成");
  } catch (error) {
    const rawMessage = error?.message || String(error);
    const message = isContextInvalidatedErrorMessage(rawMessage) ? EXT_INVALIDATED_MSG : rawMessage;
    STATE.contentEl.innerHTML = `<div style="color:#b91c1c;">分析失败：${escapeHtml(message)}</div>`;
    setStatus("分析失败", "#b91c1c");
  } finally {
    setTimeout(() => {
      hideProgress();
      STATE.isAnalyzing = false;
    }, 250);
  }
}

function exportAnalysis(format) {
  if (!STATE.lastResult) {
    setStatus("暂无可导出的分析结果", "#8a4b00");
    return;
  }

  const symbol = STATE.lastResult.symbol || "UNKNOWN";
  const timestamp = new Date(STATE.lastResult.fetchedAt || Date.now())
    .toISOString()
    .replace(/[:.]/g, "-");

  if (format === "json") {
    const filename = `${symbol}-value-analysis-${timestamp}.json`;
    downloadText(filename, JSON.stringify(STATE.lastResult, null, 2), "application/json;charset=utf-8");
    setStatus("已导出 JSON", "#166534");
    return;
  }

  const s = STATE.lastResult.snapshot;
  const text = [
    `${STATE.lastResult.name} (${symbol})`,
    `更新时间: ${new Date(STATE.lastResult.fetchedAt).toLocaleString()}`,
    "",
    "[基本面快照]",
    `现价: ${fmt(s?.quote?.current)}`,
    `PE(TTM): ${fmt(s?.valuation?.peTtm)}`,
    `PB: ${fmt(s?.valuation?.pb)}`,
    `ROE: ${formatPeriodSeries(s?.profitability?.roeSeries, "%")}`,
    `净利增速: ${fmt(s?.profitability?.netProfitGrowth, "%")}`,
    `资产负债率: ${fmt(s?.balanceSheet?.debtAssetRatio, "%")}`,
    `净现比: ${formatPeriodSeries(s?.cashFlow?.cashToProfitRatioSeries)}`,
    "",
    "[巴菲特价值分析]",
    STATE.lastResult.analysis || "",
  ].join("\n");

  const filename = `${symbol}-value-analysis-${timestamp}.txt`;
  downloadText(filename, text);
  setStatus("已导出 TXT", "#166534");
}

function handleLeftClick(event) {
  if (event.button !== 0) return;
  if (!STATE.clickTriggerEnabled) return;

  const symbol = extractSymbolFromUrl();
  if (!symbol) return;

  ensurePanel();

  if (STATE.panel && STATE.panel.contains(event.target)) {
    return;
  }

  const now = Date.now();
  if (now - STATE.lastTriggerAt < STATE.triggerIntervalMs) {
    return;
  }
  STATE.lastTriggerAt = now;

  startAnalysis({ forceRefresh: false, trigger: "左键点击" });
}

function init() {
  const symbol = extractSymbolFromUrl();
  if (!symbol) return;
  STATE.clickTriggerEnabled = true;
  ensurePanel();
  setStatus(`已识别股票 ${symbol}。在页面任意位置左键点击可触发分析。`);

  document.addEventListener("click", handleLeftClick, true);
}

init();
