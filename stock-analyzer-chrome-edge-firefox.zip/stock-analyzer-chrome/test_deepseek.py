#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import requests
import json

# DeepSeek API配置
api_key = '<YOUR_API_KEY>'
api_base_url = 'https://api.deepseek.com/v1'
model = 'deepseek-chat'

# 测试消息
test_message = '你好，请简单介绍一下你自己。'

print('🔍 测试DeepSeek API配置...')
print(f'API Key: {api_key[:10]}...')
print(f'API Base URL: {api_base_url}')
print(f'Model: {model}')
print(f'Test Message: {test_message}')
print()

try:
    response = requests.post(
        f'{api_base_url}/chat/completions',
        headers={
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {api_key}',
        },
        json={
            'model': model,
            'messages': [
                {
                    'role': 'system',
                    'content': '你是一个专业的AI助手。'
                },
                {
                    'role': 'user',
                    'content': test_message
                }
            ],
            'max_tokens': 500,
            'temperature': 0.7,
        },
        timeout=30
    )

    print(f'📡 HTTP状态码: {response.status_code}')

    if response.status_code == 200:
        data = response.json()
        content = data.get('choices', [{}])[0].get('message', {}).get('content', '')
        usage = data.get('usage', {})

        print('✅ API调用成功！')
        print(f'🤖 模型: {data.get("model", model)}')
        print(f'📊 Token使用: {usage.get("total_tokens", "未知")}')
        print(f'💬 响应内容: {content[:200]}...' if len(content) > 200 else f'💬 响应内容: {content}')
    else:
        print(f'❌ API调用失败: {response.status_code}')
        print(f'错误详情: {response.text}')

except Exception as e:
    print(f'❌ 网络或API错误: {str(e)}')