const DEFAULTS = {
  xq_a_token: "",
  xq_r_token: "",
  device_id: "",
  openai_api_key: "",
  api_base_url: "https://api.deepseek.com/v1",
  prefer_model: "deepseek-chat",
  autoFetchTokens: true,
  cacheTtlMs: 300000,
};

const qs = (selector) => document.querySelector(selector);

function setValue(id, value) {
  const el = qs(`#${id}`);
  if (el) el.value = value ?? "";
}

function getValue(id) {
  const el = qs(`#${id}`);
  return el ? el.value.trim() : "";
}

function setStatus(message, color = "#475569") {
  const el = qs("#status");
  if (!el) return;
  el.textContent = message;
  el.style.color = color;
}

function collectPayload() {
  return {
    xq_a_token: getValue("xq_a_token"),
    xq_r_token: getValue("xq_r_token"),
    device_id: getValue("device_id"),
    openai_api_key: getValue("openai_api_key"),
    api_base_url: getValue("api_base_url") || DEFAULTS.api_base_url,
    prefer_model: getValue("prefer_model") || DEFAULTS.prefer_model,
    autoFetchTokens: !!qs("#autoFetchTokens")?.checked,
    cacheTtlMs: Math.max(30000, Number(getValue("cacheTtlMs") || DEFAULTS.cacheTtlMs)),
  };
}

async function loadSettings() {
  const items = await chrome.storage.sync.get(DEFAULTS);
  setValue("xq_a_token", items.xq_a_token);
  setValue("xq_r_token", items.xq_r_token);
  setValue("device_id", items.device_id);
  setValue("openai_api_key", items.openai_api_key);
  setValue("api_base_url", items.api_base_url);
  setValue("prefer_model", items.prefer_model);
  setValue("cacheTtlMs", items.cacheTtlMs);
  qs("#autoFetchTokens").checked = !!items.autoFetchTokens;
}

async function saveSettings() {
  const payload = collectPayload();
  await chrome.storage.sync.set(payload);
  setStatus("设置已保存", "#166534");
}

async function refreshTokens() {
  const button = qs("#refreshTokens");
  button.disabled = true;
  setStatus("正在读取雪球 cookies...", "#1155cc");

  try {
    const response = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "refreshTokens" }, (res) => resolve(res));
    });

    if (!response?.ok) {
      throw new Error(response?.error || "获取失败");
    }

    const tokens = response.tokens || {};
    setValue("xq_a_token", tokens.xq_a_token || "");
    setValue("xq_r_token", tokens.xq_r_token || "");
    setValue("device_id", tokens.device_id || "");

    await saveSettings();
    setStatus(
      `Token 刷新完成：xq_a_token ${tokens.xq_a_token ? "已获取" : "未获取"}`,
      "#166534"
    );
  } catch (error) {
    setStatus(`Token 刷新失败：${error.message || String(error)}`, "#b91c1c");
  } finally {
    button.disabled = false;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadSettings().catch((error) => {
    setStatus(`加载设置失败：${error.message || String(error)}`, "#b91c1c");
  });

  qs("#save").addEventListener("click", () => {
    saveSettings().catch((error) => {
      setStatus(`保存失败：${error.message || String(error)}`, "#b91c1c");
    });
  });

  qs("#refreshTokens").addEventListener("click", () => {
    refreshTokens();
  });
});
